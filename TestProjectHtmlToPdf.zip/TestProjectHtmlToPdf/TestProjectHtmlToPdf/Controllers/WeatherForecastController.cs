
using Microsoft.AspNetCore.Hosting.Server;
using Microsoft.AspNetCore.Mvc;
using iText.Layout;
using iText.Layout.Element;
using iText.Html2pdf;
using iText.Layout.Properties;
using iText.IO.Font.Constants;
using iText.Layout.Font;
using iText.Kernel.Geom;
using iText.Kernel.Colors;
using iText.Kernel.Pdf.Canvas;
using iText.Layout.Borders;
using iText.Kernel.Pdf;
using iText.StyledXmlParser.Css.Media;
using iText.Kernel.Pdf.Xobject;
using System;
//using iTextSharp.tool.xml;
//using iTextSharp.text.pdf;
//using iTextSharp.tool.xml;
//using System.Text;
//using iTextSharp.text;
//using iTextSharp.tool.xml;
//using iTextSharp.text.pdf;
//using System.Text;

namespace TestProjectHtmlToPdf.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class WeatherForecastController : ControllerBase
    {
        private static readonly string[] Summaries = new[]
        {
        "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
    };

        private readonly ILogger<WeatherForecastController> _logger;

        public WeatherForecastController(ILogger<WeatherForecastController> logger)
        {
            _logger = logger;
        }

        [HttpPost(Name = "GetWeatherForecast")]
        //public IEnumerable<WeatherForecast> Get()
        //{
        //    return Enumerable.Range(1, 5).Select(index => new WeatherForecast
        //    {
        //        Date = DateTime.Now.AddDays(index),
        //        TemperatureC = Random.Shared.Next(-20, 55),
        //        Summary = Summaries[Random.Shared.Next(Summaries.Length)]
        //    })
        //    .ToArray();
        //}



        public FileStreamResult DownloadPDF([FromForm] string HTMLContent)
        {
            MemoryStream ms = new MemoryStream();

            PdfWriter writer = new PdfWriter(ms);

            PdfDocument pdf = new PdfDocument(writer);
           // pdf.SetDefaultPageSize(PageSize.LEGAL);
            //pdf.SetDefaultPageSize(PageSize.A4);

            Document document = new Document(pdf);
          //  document.SetTextAlignment(TextAlignment.CENTER);


            document.Add(new AreaBreak(AreaBreakType.NEXT_PAGE));

            FontProvider fontProvider = new FontProvider();
            fontProvider.AddFont(StandardFonts.TIMES_ROMAN);


            if (pdf != null && fontProvider != null)
            {
              
                ConverterProperties properties = new ConverterProperties();
               // properties.SetBaseUri("Content//css//");
                HtmlConverter.ConvertToPdf(HTMLContent, pdf, properties);

                document.Close();

                MemoryStream returnMs = new MemoryStream(ms.ToArray());
                returnMs.Position = 0; // Set position to the beginning

                return File(returnMs, "application/pdf", "HelloWorld.pdf");
            }
            else
            {
                return null;
            }

        }


        //public FileStreamResult DownloadPDF([FromForm] string htmlContent)
        //{
        //    // Make sure the HTML content is properly formatted
        //    //htmlContent = @"<?xml version=""1.0"" encoding=""UTF-8""?>
        //    //<!DOCTYPE html 
        //    //    PUBLIC ""-//W3C//DTD XHTML 1.0 Strict//EN""
        //    //    ""http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd"">
        //    //<html xmlns=""http://www.w3.org/1999/xhtml"" xml:lang=""en"" lang=""en"">
        //    //    <head>
        //    //        <title>Generated PDF</title>
        //    //    </head>
        //    //    <body>
        //    //        " + htmlContent + @"
        //    //    </body>
        //    //</html>";

        //    byte[] bytes;
        //    using (MemoryStream input = new MemoryStream(Encoding.UTF8.GetBytes(htmlContent)))
        //    {
        //        using (MemoryStream output = new MemoryStream())
        //        {
        //            Document document = new Document(PageSize.A4, 50, 50, 50, 50);
        //            PdfWriter writer = PdfWriter.GetInstance(document, output);
        //            writer.CloseStream = false;
        //            document.Open();

        //            XMLWorkerHelper.GetInstance().ParseXHtml(writer, document, input, null as Stream);
        //            document.Close();
        //            output.Position = 0;

        //            bytes = output.ToArray();
        //        }
        //    }

        //    return File(new MemoryStream(bytes), "application/pdf", "GeneratedPDF.pdf");
        //}




        //public FileStreamResult DownloadPDF([FromForm] string HTMLContent)
        //{
        //    if (string.IsNullOrEmpty(HTMLContent))
        //    {
        //        return new FileStreamResult(Stream.Null, "HTML content is empty or null.");
        //    }

        //    try
        //    {
        //        byte[] pdfData;
        //        using (var stream = new MemoryStream())
        //        {
        //            using (var document = new iTextSharp.text.Document())
        //            {
        //                PdfWriter writer = PdfWriter.GetInstance(document, stream);
        //                document.Open();

        //                // Explicitly specify the encoding when parsing HTML
        //                using (var htmlStream = new MemoryStream(Encoding.UTF8.GetBytes(HTMLContent)))
        //                {
        //                    XMLWorkerHelper.GetInstance().ParseXHtml(writer, document, htmlStream, null, Encoding.UTF8);
        //                }

        //                document.Close();
        //            }

        //            pdfData = stream.ToArray();
        //        }

        //        if (pdfData != null && pdfData.Length > 0)
        //        {
        //            MemoryStream returnMs = new MemoryStream(pdfData);
        //            returnMs.Position = 0; // Set position to the beginning

        //            return File(returnMs, "application/pdf", "generated_file.pdf");
        //        }
        //        else
        //        {
        //            return new FileStreamResult(Stream.Null, "PDF generation failed or empty.");
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        return new FileStreamResult(Stream.Null, $"Error generating PDF: {ex.Message}");
        //    }
        //}


    }
}